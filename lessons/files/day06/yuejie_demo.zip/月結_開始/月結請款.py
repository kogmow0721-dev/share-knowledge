#!/usr/bin/env python3
"""順發食材行 月結請款單產生工具

用法（在「月結」資料夾裡）：
    python3 月結請款.py 2026-09

讀取：出貨紀錄/<月份>/*.csv、客戶條件.xlsx、退貨紀錄.xlsx（只讀不改）
輸出：請款單/<月份>/ 底下
    <月份>_<店名>_請款單.xlsx   （一家一個）
    <月份>_總表.xlsx
    請款訊息.txt
    需要確認.txt               （程式發現的疑問，供對帳參考）

算法：
    各送貨點未稅貨款加總 → 乘折扣（四捨五入到元）→ 扣當月該扣的退貨
    → 營業稅 5%（四捨五入到元）→ 應付總額
"""
import csv
import glob
import os
import re
import sys
from collections import defaultdict
from decimal import Decimal, ROUND_HALF_UP

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side

BASE = os.path.dirname(os.path.abspath(__file__))
TAX_RATE = Decimal("0.05")
SHOP = "順發食材行"

# ---------- 小工具 ----------

def rnd(x):
    """四捨五入到整數元（0.5 一律進位，不用銀行家算法）"""
    return int(Decimal(str(x)).quantize(Decimal("1"), rounding=ROUND_HALF_UP))


def base_name(name):
    """『老陳牛肉麵（中山店）』→『老陳牛肉麵』"""
    return re.sub(r"[（(].*?[）)]", "", name).strip()


def branch_of(name):
    m = re.search(r"[（(](.*?)[）)]", name)
    return m.group(1) if m else ""


def money(x):
    return f"{x:,}"


# ---------- 讀資料 ----------

def load_customers():
    wb = load_workbook(os.path.join(BASE, "客戶條件.xlsx"), data_only=True)
    ws = wb.active
    rows = list(ws.iter_rows(values_only=True))
    head = rows[0]
    cust = {}
    for r in rows[1:]:
        if not r[1]:
            continue
        d = dict(zip(head, r))
        d["折扣"] = Decimal(str(d["折扣"]))
        d["統編"] = str(d["統編"]).strip() if d["統編"] else ""
        d["折扣變更"] = parse_discount_change(d.get("備註"))
        cust[d["店名"].strip()] = d
    return cust


def parse_discount_change(note):
    """備註裡寫『2026/10/16 起改 95 折』→ ('2026-10-16', 0.95)；沒有就回 None"""
    if not note:
        return None
    m = re.search(r"(\d{4})/(\d{1,2})/(\d{1,2})\s*起改\s*(\d+(?:\.\d+)?)\s*折", str(note))
    if not m:
        return None
    y, mo, d, z = m.groups()
    z = Decimal(z)
    rate = z / 100 if z >= 10 else z / 10      # 95 折 → 0.95；9 折 → 0.9
    return (f"{int(y):04d}-{int(mo):02d}-{int(d):02d}", rate)


def discount_for(c, date):
    ch = c["折扣變更"]
    if ch and date >= ch[0]:
        return ch[1]
    return c["折扣"]


def load_shipments(month):
    folder = os.path.join(BASE, "出貨紀錄", month)
    files = sorted(glob.glob(os.path.join(folder, "*.csv")))
    if not files:
        sys.exit(f"找不到 {folder} 底下的出貨紀錄")
    lines = []
    for f in files:
        with open(f, encoding="utf-8-sig", newline="") as fh:
            for r in csv.DictReader(fh):
                r = {k.strip(): (v or "").strip() for k, v in r.items()}
                if not r.get("客戶"):
                    continue
                r["_檔案"] = os.path.basename(f)
                lines.append(r)
    return lines


def load_returns(month):
    wb = load_workbook(os.path.join(BASE, "退貨紀錄.xlsx"), data_only=True)
    ws = wb.active
    rows = list(ws.iter_rows(values_only=True))
    head = rows[0]
    out = []
    for r in rows[1:]:
        if not r[0]:
            continue
        d = dict(zip(head, r))
        d["退貨日期"] = str(d["退貨日期"])[:10]
        out.append(d)
    return out


# ---------- 計算 ----------

def build(month):
    cust = load_customers()
    ships = load_shipments(month)
    rets = load_returns(month)
    warn = defaultdict(list)       # 店名 → 疑問
    general = []                   # 不屬於特定客戶的提醒

    bills = {}                     # 店名 → 資料
    for ln in ships:
        full = ln["客戶"]
        shop = base_name(full)
        if shop not in cust:
            general.append(f"出貨紀錄有「{full}」，但客戶條件表找不到這家，未開請款單。")
            continue
        b = bills.setdefault(shop, {"lines": [], "returns": [], "deferred": []})
        qty, price, sub = Decimal(ln["數量"]), Decimal(ln["單價"]), Decimal(ln["小計"])
        if qty * price != sub:
            warn[shop].append(f"{ln['日期']} {ln['品名']}：數量×單價 與 小計對不起來，已採用小計。")
        b["lines"].append({
            "日期": ln["日期"], "單號": ln["出貨單號"], "送貨點": branch_of(full),
            "品名": ln["品名"], "數量": qty, "單位": ln["單位"], "單價": price, "小計": sub,
        })
        if not ln["日期"].startswith(month):
            warn[shop].append(f"出貨日期 {ln['日期']} 不在 {month}（檔案 {ln['_檔案']}）。")

    for r in rets:
        shop = base_name(str(r["客戶"]))
        if shop not in cust:
            general.append(f"退貨紀錄有「{r['客戶']}」，但客戶條件表找不到這家。")
            continue
        amt = Decimal(str(r["金額"]))
        item = {"日期": r["退貨日期"], "送貨點": branch_of(str(r["客戶"])), "品名": r["品名"],
                "數量": r["數量"], "單位": r["單位"], "單價": r["單價"], "金額": amt, "原因": r["原因"]}
        if str(r["從哪個月扣"]).strip() == month:
            if shop not in bills:
                general.append(f"「{shop}」{month} 有退貨可扣，但這個月沒有出貨，未開請款單，退貨 {money(int(amt))} 元沒扣到。")
                continue
            bills[shop]["returns"].append(item)
        elif str(r["從哪個月扣"]).strip() < month:
            general.append(f"「{shop}」{r['退貨日期']} 的退貨（{r['品名']} {money(int(amt))} 元）註明要從 {r['從哪個月扣']} 扣，"
                           f"比 {month} 還早，請確認有沒有扣漏。")

    # 金額
    for shop, b in bills.items():
        c = cust[shop]
        by_rate = defaultdict(Decimal)
        for ln in b["lines"]:
            by_rate[discount_for(c, ln["日期"])] += ln["小計"]
        gross = sum(by_rate.values())
        discounted = sum(rnd(v * rate) for rate, v in by_rate.items())
        ret_total = sum(r["金額"] for r in b["returns"])
        taxable = discounted - int(ret_total)
        tax = rnd(Decimal(taxable) * TAX_RATE)
        b.update(gross=int(gross), by_rate={k: int(v) for k, v in by_rate.items()},
                 discounted=int(discounted), discount_amt=int(gross) - int(discounted),
                 ret_total=int(ret_total), taxable=int(taxable), tax=tax, total=int(taxable) + tax)

        # ---- 疑問 ----
        if len(by_rate) > 1:
            warn[shop].append("本月折扣中途有變，已依出貨日期分段計算："
                              + "、".join(f"{float(k*100):g}% 折後 ← {money(v)} 元" for k, v in by_rate.items()))
        ch = c["折扣變更"]
        if ch and ch[0] > month + "-31":
            warn[shop].append(f"{ch[0]} 起折扣改為 {float(ch[1]*100):g}%，本月不受影響，下個月起自動套用。")
        if c["發票"] == "二聯式" and c["統編"]:
            warn[shop].append("發票是二聯式，但客戶條件表有填統編，請確認應開二聯還是三聯。")
        if c["發票"] == "三聯式" and not c["統編"]:
            warn[shop].append("發票是三聯式，但客戶條件表沒有統編。")
        if c["結帳日"] != "月底":
            late = sum(ln["小計"] for ln in b["lines"] if ln["日期"][8:10] > "25")
            warn[shop].append(f"結帳日是「{c['結帳日']}」，但本次仍照整個月（1～月底）計算；"
                              f"26 號之後的出貨共 {money(int(late))} 元（未稅、折扣前），是否要算到下一期請確認。")
        if c["折扣"] < 1 and b["ret_total"]:
            warn[shop].append(f"退貨 {money(b['ret_total'])} 元是按原價從折扣後金額扣掉；"
                              f"若退貨也要先打折再扣，會少扣 {money(rnd(Decimal(b['ret_total'])*(1-c['折扣'])))} 元。")

    # 沒出貨的客戶
    for shop in cust:
        if shop not in bills:
            general.append(f"「{shop}」{month} 沒有出貨紀錄，未開請款單。")

    # 留到下個月扣的退貨（只是提醒）
    for r in rets:
        shop = base_name(str(r["客戶"]))
        if str(r["從哪個月扣"]).strip() > month and r["退貨日期"][:7] <= month and shop in bills:
            bills[shop]["deferred"].append(r)
            warn[shop].append(f"{r['退貨日期']} 退貨「{r['品名']}」{money(int(r['金額']))} 元，"
                              f"依紀錄留到 {r['從哪個月扣']} 才扣，本月沒扣。")
    return cust, bills, warn, general


# ---------- 輸出 ----------

FONT = "Microsoft JhengHei"
NAVY = "1F3A5F"
CREAM = "FBF6EC"
GOLD = "C8963E"
GREY = "F2F2F2"
thin = Side(style="thin", color="D9D9D9")
BOX = Border(left=thin, right=thin, top=thin, bottom=thin)


def f(bold=False, size=11, color="000000"):
    return Font(name=FONT, bold=bold, size=size, color=color)


def write_bill(path, month, shop, c, b):
    wb = Workbook()
    ws = wb.active
    ws.title = "請款單"
    ws.sheet_view.showGridLines = False
    widths = [12, 13, 11, 14, 9, 8, 10, 12]
    for i, w in enumerate(widths):
        ws.column_dimensions["ABCDEFGH"[i]].width = w
    y, m = month.split("-")

    ws.merge_cells("A1:H1")
    ws["A1"] = f"{SHOP}　月結請款單"
    ws["A1"].font = f(True, 18, "FFFFFF")
    ws["A1"].fill = PatternFill("solid", fgColor=NAVY)
    ws["A1"].alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[1].height = 38

    info = [
        ("客戶抬頭", c["抬頭"]), ("統一編號", c["統編"] or "（無）"),
        ("請款期間", f"{y} 年 {int(m)} 月"), ("聯絡人", c["聯絡人"]),
        ("發票", c["發票"]), ("店名", shop),
    ]
    r = 3
    for i in range(0, len(info), 2):
        for j, (k, v) in enumerate(info[i:i + 2]):
            col = 1 + j * 4
            ws.cell(r, col, k).font = f(True, 10, "7A6A4F")
            ws.merge_cells(start_row=r, start_column=col + 1, end_row=r, end_column=col + 3)
            ws.cell(r, col + 1, v).font = f(False, 11)
        r += 1
    for rr in range(3, r):
        for cc in range(1, 9):
            ws.cell(rr, cc).fill = PatternFill("solid", fgColor=CREAM)
    r += 1

    branches = sorted({ln["送貨點"] for ln in b["lines"] if ln["送貨點"]})
    heads = ["日期", "出貨單號", "送貨點", "品名", "數量", "單位", "單價", "小計"]
    for j, h in enumerate(heads):
        cell = ws.cell(r, 1 + j, h)
        cell.font = f(True, 10, "FFFFFF")
        cell.fill = PatternFill("solid", fgColor=GOLD)
        cell.alignment = Alignment(horizontal="center")
        cell.border = BOX
    r += 1
    first = r
    for n, ln in enumerate(sorted(b["lines"], key=lambda x: (x["日期"], x["單號"], x["送貨點"]))):
        vals = [ln["日期"], ln["單號"], ln["送貨點"], ln["品名"], int(ln["數量"]), ln["單位"],
                int(ln["單價"]), int(ln["小計"])]
        for j, v in enumerate(vals):
            cell = ws.cell(r, 1 + j, v)
            cell.font = f(False, 10)
            cell.border = BOX
            if n % 2:
                cell.fill = PatternFill("solid", fgColor=GREY)
            if j >= 4 and j != 5:
                cell.alignment = Alignment(horizontal="right")
                if j >= 6:
                    cell.number_format = "#,##0"
            if j == 5:
                cell.alignment = Alignment(horizontal="center")
        r += 1
    r += 1

    def row(label, val, bold=False, note="", fill=None):
        nonlocal r
        ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=5)
        ws.cell(r, 1, label).font = f(bold, 11)
        ws.cell(r, 1).alignment = Alignment(horizontal="right")
        ws.merge_cells(start_row=r, start_column=6, end_row=r, end_column=7)
        ws.cell(r, 6, note).font = f(False, 9, "888888")
        ws.cell(r, 6).alignment = Alignment(horizontal="center")
        v = ws.cell(r, 8, val)
        v.font = f(bold, 12 if bold else 11)
        v.number_format = '#,##0;[Red]-#,##0'
        v.alignment = Alignment(horizontal="right")
        if fill:
            for cc in range(1, 9):
                ws.cell(r, cc).fill = PatternFill("solid", fgColor=fill)
        r += 1

    row("本月貨款合計（未稅）", b["gross"])
    if b["discount_amt"]:
        if len(b["by_rate"]) == 1:
            rate = next(iter(b["by_rate"]))
            note = f"{float(rate*100):g}% 折"
        else:
            note = "折扣分段"
        row("折扣", -b["discount_amt"], note=note)
    row("折扣後貨款", b["discounted"])
    for rt in b["returns"]:
        place = f"{rt['送貨點']}　" if rt["送貨點"] else ""
        row(f"退貨扣除　{rt['日期']}　{place}{rt['品名']} {rt['數量']}{rt['單位']}（{rt['原因']}）", -int(rt["金額"]))
    row("未稅金額", b["taxable"], True)
    row("營業稅 5%", b["tax"])
    row("應付總額（含稅）", b["total"], True, fill="F6E7C8")
    ws.row_dimensions[r - 1].height = 26
    r += 1
    ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=8)
    ws.cell(r, 1, f"{SHOP}　感謝您的支持，如有疑問歡迎隨時與我們聯絡。").font = f(False, 9, "888888")
    ws.cell(r, 1).alignment = Alignment(horizontal="center")

    ws.freeze_panes = ws.cell(first, 1) if False else None
    ws.page_setup.orientation = "portrait"
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    wb.save(path)


def write_summary(path, month, cust, bills, warn):
    wb = Workbook()
    ws = wb.active
    ws.title = f"{month} 總表"
    heads = ["編號", "店名", "抬頭", "統編", "發票", "聯絡人", "貨款合計(未稅)", "折扣", "折扣金額",
             "折扣後貨款", "退貨扣除", "未稅金額", "營業稅", "應付總額", "備註"]
    ws.append(heads)
    for j in range(1, len(heads) + 1):
        c = ws.cell(1, j)
        c.font = f(True, 11, "FFFFFF")
        c.fill = PatternFill("solid", fgColor=NAVY)
        c.alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[1].height = 28
    order = sorted(bills, key=lambda s: cust[s]["編號"])
    for shop in order:
        c, b = cust[shop], bills[shop]
        disc = "、".join(f"{float(k*100):g}%" for k in b["by_rate"])
        notes = [w for w in warn.get(shop, [])]
        ws.append([c["編號"], shop, c["抬頭"], c["統編"], c["發票"], c["聯絡人"], b["gross"], disc,
                   -b["discount_amt"], b["discounted"], -b["ret_total"], b["taxable"], b["tax"], b["total"],
                   "；".join(notes)])
    n = len(order)
    last = n + 1
    ws.append(["", "合計"] + [""] * 4 + [f"=SUM({col}2:{col}{last})" if col else "" for col in
                                        ["G", None, "I", "J", "K", "L", "M", "N"]] + [""])
    # 合計列也寫成確定的數字，避免沒有重新計算的程式看到空白
    tot = {7: sum(b["gross"] for b in bills.values()), 9: -sum(b["discount_amt"] for b in bills.values()),
           10: sum(b["discounted"] for b in bills.values()), 11: -sum(b["ret_total"] for b in bills.values()),
           12: sum(b["taxable"] for b in bills.values()), 13: sum(b["tax"] for b in bills.values()),
           14: sum(b["total"] for b in bills.values())}
    for col, v in tot.items():
        ws.cell(last + 1, col, v)
    for row_ in ws.iter_rows(min_row=2, max_row=last + 1):
        for c in row_:
            c.font = f(c.row == last + 1)
            c.border = BOX
            if c.column in (7, 9, 10, 11, 12, 13, 14):
                c.number_format = "#,##0;[Red]-#,##0"
                c.alignment = Alignment(horizontal="right")
            if c.column == 8:
                c.alignment = Alignment(horizontal="center")
            if c.column == 15:
                c.alignment = Alignment(wrap_text=True, vertical="top")
            if c.row % 2 == 1 and c.row <= last:
                c.fill = PatternFill("solid", fgColor=GREY)
    for c in ws[last + 1]:
        c.fill = PatternFill("solid", fgColor="F6E7C8")
    for col, w in zip("ABCDEFGHIJKLMNO", [7, 16, 22, 11, 8, 11, 14, 9, 11, 13, 10, 12, 10, 13, 60]):
        ws.column_dimensions[col].width = w
    ws.freeze_panes = "C2"
    wb.save(path)


def line_message(month, shop, c, b):
    m = int(month.split("-")[1])
    lines = [f"{c['聯絡人']}您好，我是順發食材行。",
             f"{m} 月份的貨款幫您整理好了，請款明細如下："]
    lines.append(f"・本月貨款（未稅）：{money(b['gross'])} 元")
    if b["discount_amt"]:
        lines.append(f"・折扣：-{money(b['discount_amt'])} 元")
    if b["ret_total"]:
        names = "、".join(r["品名"] for r in b["returns"])
        lines.append(f"・退貨扣除（{names}）：-{money(b['ret_total'])} 元")
    lines.append(f"・營業稅 5%：{money(b['tax'])} 元")
    lines.append(f"本月應付總額：{money(b['total'])} 元（含稅）")
    lines.append("詳細明細請見附上的請款單，麻煩您核對看看，有任何問題再跟我說。謝謝您！")
    return "\n".join(lines)


def main():
    if len(sys.argv) != 2 or not re.fullmatch(r"\d{4}-\d{2}", sys.argv[1]):
        sys.exit("用法：python3 月結請款.py 2026-09")
    month = sys.argv[1]
    cust, bills, warn, general = build(month)
    out = os.path.join(BASE, "請款單", month)
    os.makedirs(out, exist_ok=True)

    order = sorted(bills, key=lambda s: cust[s]["編號"])
    for shop in order:
        write_bill(os.path.join(out, f"{month}_{shop}_請款單.xlsx"), month, shop, cust[shop], bills[shop])
    write_summary(os.path.join(out, f"{month}_總表.xlsx"), month, cust, bills, warn)

    with open(os.path.join(out, "請款訊息.txt"), "w", encoding="utf-8") as fh:
        for shop in order:
            fh.write(f"【{shop}】\n{line_message(month, shop, cust[shop], bills[shop])}\n\n{'-'*30}\n\n")

    with open(os.path.join(out, "需要確認.txt"), "w", encoding="utf-8") as fh:
        for t in general:
            fh.write(f"※ {t}\n")
        for shop in order:
            for t in warn.get(shop, []):
                fh.write(f"【{shop}】{t}\n")

    total = sum(bills[s]["total"] for s in order)
    print(f"已產生 {len(order)} 家請款單，應收總額（含稅）{total:,} 元 → {out}")
    for t in general:
        print("※", t)


if __name__ == "__main__":
    main()
